<?php
/**
 * Created by PhpStorm.
 * User: Nataraj Bingi
 * Date: 10/16/2019
 * Time: 11:42 PM
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'snsadmin');
define('DB_PASS', 'snsadmin@123');
define('DB_NAME', 'make_in');

/*define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'make_in');*/
define( 'API_ACCESS_KEY_ADMIN', 'AAAAIowuBQs:APA91bGj3xghbC-bz0ESF8oynBcNwywGsGEBjE-GKTKbCWqDcSXhrGnIh2zuTtDErUkmLZvT_ywUr-qxhjq-YQ59SU7u3fOcIv9fqd-wil99MxqgC6r3IqfzhalLw4H-b5-eWkO0p1KY');
define( 'API_ACCESS_KEY_USERS', 'AAAAjsB7b-o:APA91bGprI2wPvQvr6XAqZWcwfXLX_n84859p_13C22b7Y5Sf0qgC3-fQR6pi9YY00AZCsp03vB3UWUXaJTcq3o_5U5WIGZ5JLp_uwM39l5SoIIOhdODJRRLNXtNBL7OtvFvSRfVrSor');

define('UPLOAD_PATH', '/uploads/');
define('one', 'addcategory');
define('two', 'updatecategory');
define('three', 'deletecategory');
define('four', 'addsubcategory');
define('five', 'updatesubcategory');
define('six', 'deletesubcategory');
define('seven', 'userregister');
define('eight', 'userupdate');
define('userprofpicupdate', 'userprofpicupdate');
define('updateuserpas', 'updateuserpas');
define('nine', 'userdelete');
define('ten', 'getallprods');
define('oneone', 'getallprodsubs');
define('onetwo', 'getallusers');
define('onethree', 'userprodreq');
define('onefour', 'userprodrequpdate');
define('onefive', 'userprodreqdelete');
define('getAllProdReqs', 'getAllProdReqs');
define('userprodreqgetll', 'userprodreqgetll');
define('onesix', 'login');
define('oneseven', 'getallusers');
define('oneight', 'getallsubs');
//define('oneight', 'addcategory');
define('onenine', 'pushnoti');
//define('twenty', 'addcategory');

//-----------------------------//
